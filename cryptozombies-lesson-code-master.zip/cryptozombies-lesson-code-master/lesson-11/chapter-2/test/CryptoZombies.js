const CryptoZombies = artifacts.require("CryptoZombies");
contract("CryptoZombies", (accounts) => {
    it("should be able to create a new zombie", () => {

    })
})
