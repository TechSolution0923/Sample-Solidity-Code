#!/usr/bin/env bash

echo "
src/js/metacoin-config.js
node_modules
build
.env
" > .gitignore