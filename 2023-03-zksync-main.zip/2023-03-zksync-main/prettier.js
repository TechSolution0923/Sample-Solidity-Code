module.exports = {
  "printWidth": 120,
  "tabWidth": 4,
  "useTabs": false,
  "singleQuote": false,
  "bracketSpacing": false,
  "explicitTypes": "always"
};
